import Cocoa

let filename = "paris.jpg"
print(filename.hasSuffix(".jpg"))

let number = 120
print(number.isMultiple(of: 3))

let goodDogs = true
var gameOver = false
print(gameOver)
gameOver.toggle()
print(gameOver)
let isMulti = 120.isMultiple(of: 3)

var isAuth = false
isAuth = !isAuth
print(isAuth)
isAuth = !isAuth
print(isAuth)

let firstPart = "Hello, "
let secondPart = "world!"

let greeting = firstPart + secondPart

let people = "Haters"
let action = "hate"
let lyric = people + " gonna " + action

let luggageCode = "1" + "2" + "3" + "4" + "5"

let quote = "Then he tappe a sign saying \"Believe\" and walked away."

let name = "Taylor"
let age = 26
let message = "Hello my name is \(name) and I'm \(age) years old."
print(message)

let newNumber = 11
let missionMessage = "Apollo \(newNumber) landed on the moon."
